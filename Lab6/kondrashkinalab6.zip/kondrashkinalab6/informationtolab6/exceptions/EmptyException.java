/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kondrashkinalab6.informationtolab6.exceptions;

/**
 *
 * @author Kseny
 */
public class EmptyException extends Exception {
    public EmptyException(){
        super("������ ����.\n");
    }
}
