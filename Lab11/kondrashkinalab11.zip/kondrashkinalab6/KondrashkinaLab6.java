package kondrashkinalab6;
/**
 *
 * @author Ksenya Kondrashkina
 */
public class KondrashkinaLab6 {

    public static void main(String[] args) { 
        /*int countMealLunch = 4, countMealDinner = 3;              
        int countPerson = 4;
        
        UserWork todayUserWork = new UserWork(countPerson, countMealLunch, countMealDinner);
        
        todayUserWork.Hello();*/
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserWorkJFrame().setVisible(true);
            }
        });
    }
}
