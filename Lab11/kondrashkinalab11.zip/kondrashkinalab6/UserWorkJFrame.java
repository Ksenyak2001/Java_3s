/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package kondrashkinalab6;
import kondrashkinalab6.informationtolab6.exceptions.*;
import kondrashkinalab6.informationtolab6.*;
import java.util.ArrayList;
import java.io.*;
import java.util.Scanner;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
/**
 *
 * @author Kseny
 */
public class UserWorkJFrame extends javax.swing.JFrame {

    int countPerson = 4;
    int step = 0;
    TestPeople people;
    ArrayList<Lunch> allLunch;    
    ArrayList<Food> all_food;
    Scanner console;
    /**
     * Creates new form UserWorkJFrame
     */
    public UserWorkJFrame() {
        initComponents();        
        String encoding = System.getProperty("console.encoding", "utf-8");
        console = new Scanner(System.in, encoding);
        countPerson = 4;
        people = new TestPeople(countPerson);
        allLunch = new ArrayList<>();
        all_food = new ArrayList<>();
        jButtonBye.hide();
    }
    public void readFile(){
        FileInputStream fis = null;
        
        try {
            fis = new FileInputStream("food.csv");
            System.out.println("***");
            int length = fis.available();
            byte[] data = new byte[length];
            fis.read(data);
            String text = new String(data);
            String[] elements = text.split("\n");
            for (String elem : elements){
                String[] food_data = elem.split(";");
                try {
                    all_food.add(new Food(food_data[0], 
                            Double.parseDouble(food_data[1]),
                            Double.parseDouble(food_data[3]), 
                            Double.parseDouble(food_data[2])));
                } catch(Exception e){
                    System.out.println(e.getMessage());
                    System.out.printf("���-�� ����� �� ��� � �����������: %s\n", food_data[0]);
                    JOptionPane.showMessageDialog(null,
                            String.format("���-�� ����� �� ��� � �����������: %s\n", food_data[0]),
                            "Ooops",JOptionPane.ERROR_MESSAGE);
                }                
            }            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                fis.close();
                System.out.println("&");
                System.out.println(all_food.size());
                System.out.println("&");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    public void setPeopleLunch() {
        //� ���� 4:
        //2.������� 4 ���������� ������ ���� � ��������� ��������.
        //setFoodList();
        //����
        people.addPerson(new Person("����", 164.8, 68, 19,
                true, 1, true));
        Lunch lunchEmma = new Lunch(0, all_food.size());        
        //���� : ����� ������, ��� �������, ������������ ����, ������� �������
        //���� : ������� ��-��������, ����� �����������, ����� ���������� 
        int count_meals = 0;
        for (int i = 0; i < all_food.size(); ++i){
            if(count_meals <= 10) {
                int w = RandomChoice.randomChoiceWeight();
                if (w != 0) {
                    count_meals++;
                }
                lunchEmma.addMeal(i, w, all_food);
            } else {
                lunchEmma.addMeal(i, 0, all_food);
            }
        }
        //����� �������� ��� ��������: changeWeight(String foodName, int gramm)
        lunchEmma.changeWeight("����� ������", 86);
        System.out.println("&");
        System.out.println(lunchEmma.size());
        System.out.println("&");
        allLunch.add(lunchEmma);
        //�����
        people.addPerson(new Person("�����", 187.3, 70.3, 40, 
                false, 5, true));
        Lunch lunchJake = new Lunch(all_food.size(), 0);       
        
        count_meals = 0;
        for (int i = 0; i < all_food.size(); ++i){
            if(count_meals <= 10) {
                int w = RandomChoice.randomChoiceWeight();
                if (w != 0) {
                    count_meals++;
                }
                lunchJake.addMeal(i, w, all_food);
            } else {
                lunchJake.addMeal(i, 0, all_food);
            }
        }
        allLunch.add(lunchJake);
        //����
        people.addPerson(new Person("����", 182, 71.3, 36, 
                true, 3, true));
        Lunch lunchRuta = new Lunch(0, all_food.size());        
        count_meals = 0;
        for (int i = 0; i < all_food.size(); ++i){
            if(count_meals <= 10) {
                int w = RandomChoice.randomChoiceWeight();
                if (w != 0) {
                    count_meals++;
                }
                lunchRuta.addMeal(i, w, all_food);
            } else {
                lunchRuta.addMeal(i, 0, all_food);
            }
        }
        allLunch.add(lunchRuta);
        //����
        people.addPerson(new Person("����", 155.5, 64.8, 67, 
                false, 1, true));
        Lunch lunchLiam = new Lunch(0, all_food.size());        
        //���� : ������� ��-��������, ��� ���������, ��������� �������, ����� �����������
        //���� : ����� �������� �������, �������, ��� ����� ������
        /*lunchLiam.addMeal(4, 44, all_food);
        lunchLiam.addMeal(7, 105, all_food);
        lunchLiam.addMeal(11, 68, all_food);
        lunchLiam.addMeal(5, 48, all_food);
        lunchLiam.addMeal(9, 76, all_food);
        lunchLiam.addMeal(10, 62, all_food);
        lunchLiam.addMeal(8, 136, all_food);*/
        count_meals = 0;
        for (int i = 0; i < all_food.size(); ++i){
            if(count_meals <= 10) {
                int w = RandomChoice.randomChoiceWeight();
                if (w != 0) {
                    count_meals++;
                }
                lunchLiam.addMeal(i, w, all_food);
            } else {
                lunchLiam.addMeal(i, 0, all_food);
            }
        }
        allLunch.add(lunchLiam);
        //c.������� �������� DCI �� ����� ��� ������� ��������;
        people.countAllDCI();
}
    public void FirstCount() {
        //  ����������, ��������� �� ����� ������� ��� ������� �������� 
        //  � ������� ��������� �� �����. 
        double[] resCalories = new double[countPerson];
        //System.out.println("��������� ������:\n");
        for (int i =0; i < countPerson; i++){
            //people.printPerson(i, 0);
            resCalories[i] = allLunch.get(i).countResCalories();
            people.setPersonCalory(i,resCalories[i], true);
        }
        //people.checkDifference(resCalories);   
    }
    public void printDifDCICal(int i){
        people.printPerson(i, 0);
        jTextFieldName.setText(people.getName(i));
        people.printCalories(i);
        people.printDifference(i); 
        
        String info = people.returnInfoPerson(i,0);
        info += String.format("\n�������: %.2f.\n\n", people.getCalories(i));
        info += people.returnDifference(i);
        jTextAreaInfoDCI.setText(info);
    }
    void getNames(JComboBox<String> jComboBoxTemp){
        jComboBoxTemp.removeAllItems();
        int n = people.size();
        System.out.println("^^^");
        //System.out.println(n);
        for (int i = 0; i < n; ++i){
            String c =people.getName(i);
            //System.out.println(c);
            jComboBoxTemp.addItem(c);
        }
    }
    void getFoodNames(JComboBox<String> jComboBoxTemp){
        jComboBoxTemp.removeAllItems();
        int n = all_food.size();
        System.out.println("^^^");
        //System.out.println(n);
        for (int i = 0; i < n; ++i){
            String c = all_food.get(i).getInfo(i);
            //System.out.println(c);
            jComboBoxTemp.addItem(c);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroupHello = new javax.swing.ButtonGroup();
        jDialogHello = new javax.swing.JDialog();
        jPanel2 = new javax.swing.JPanel();
        jTextFieldDefaultText = new javax.swing.JTextField();
        jRadioButtonHelloYes = new javax.swing.JRadioButton();
        jRadioButtonHelloNo = new javax.swing.JRadioButton();
        jDialogInstruction = new javax.swing.JDialog();
        jPanel3 = new javax.swing.JPanel();
        jTextFieldQuestionInstruction = new javax.swing.JTextField();
        jRadioButtonDCI = new javax.swing.JRadioButton();
        jRadioButtonClear = new javax.swing.JRadioButton();
        jRadioButtonAdd = new javax.swing.JRadioButton();
        jComboBoxPeople = new javax.swing.JComboBox<>();
        jButtonGoGo = new javax.swing.JButton();
        jLabelPicture = new javax.swing.JLabel();
        jButtonExit = new javax.swing.JButton();
        jRadioButtonSeeList = new javax.swing.JRadioButton();
        jRadioButtonBorn = new javax.swing.JRadioButton();
        buttonGroupInstruction = new javax.swing.ButtonGroup();
        jDialogDCIPerson = new javax.swing.JDialog();
        jPanel4 = new javax.swing.JPanel();
        jTextFieldName = new javax.swing.JTextField();
        jButtonCloseDCI = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextAreaInfoDCI = new javax.swing.JTextArea();
        jDialogAdd = new javax.swing.JDialog();
        jPanel5 = new javax.swing.JPanel();
        jComboBoxFood = new javax.swing.JComboBox<>();
        jButtonGoGrCalory = new javax.swing.JButton();
        jButtonExitToInstruction = new javax.swing.JButton();
        jTextFieldAskGrammCalory = new javax.swing.JTextField();
        jRadioButtonGramm = new javax.swing.JRadioButton();
        jRadioButtonCalory = new javax.swing.JRadioButton();
        jTextFieldAskNewGrCal = new javax.swing.JTextField();
        jButtonBack = new javax.swing.JButton();
        jTextFieldNewGrCal = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextAreaGrCal = new javax.swing.JTextArea();
        buttonGroupGrCal = new javax.swing.ButtonGroup();
        jDialogSeeList = new javax.swing.JDialog();
        jPanel6 = new javax.swing.JPanel();
        jTextFieldListPersonName = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextAreaRacion = new javax.swing.JTextArea();
        jButtonBackFromList = new javax.swing.JButton();
        jDialogBorn = new javax.swing.JDialog();
        jPanel7 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jButtonCreate = new javax.swing.JButton();
        jTextField2 = new javax.swing.JTextField();
        jTextFieldAnswerName = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jRadioButtonMale = new javax.swing.JRadioButton();
        jRadioButtonFemale = new javax.swing.JRadioButton();
        jSlider2 = new javax.swing.JSlider();
        jSlider3 = new javax.swing.JSlider();
        jTextField5 = new javax.swing.JTextField();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jRadioButton5 = new javax.swing.JRadioButton();
        jRadioButton6 = new javax.swing.JRadioButton();
        jTextField7 = new javax.swing.JTextField();
        jSlider4 = new javax.swing.JSlider();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabelAge = new javax.swing.JLabel();
        jLabelHeight = new javax.swing.JLabel();
        jLabelWeight = new javax.swing.JLabel();
        jRadioButton7 = new javax.swing.JRadioButton();
        buttonGroupGender = new javax.swing.ButtonGroup();
        jSlider1 = new javax.swing.JSlider();
        buttonGroupActivity = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jButtonStart = new javax.swing.JButton();
        jButtonBye = new javax.swing.JButton();

        jTextFieldDefaultText.setEditable(false);
        jTextFieldDefaultText.setBackground(new java.awt.Color(255, 255, 255));
        jTextFieldDefaultText.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldDefaultText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldDefaultTextActionPerformed(evt);
            }
        });

        buttonGroupHello.add(jRadioButtonHelloYes);
        jRadioButtonHelloYes.setText("��");
        jRadioButtonHelloYes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonHelloYesActionPerformed(evt);
            }
        });

        buttonGroupHello.add(jRadioButtonHelloNo);
        jRadioButtonHelloNo.setText("���");
        jRadioButtonHelloNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonHelloNoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jRadioButtonHelloYes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextFieldDefaultText, javax.swing.GroupLayout.DEFAULT_SIZE, 440, Short.MAX_VALUE)
                    .addComponent(jRadioButtonHelloNo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 56, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(jTextFieldDefaultText, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButtonHelloYes)
                .addGap(18, 18, 18)
                .addComponent(jRadioButtonHelloNo)
                .addContainerGap(122, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jDialogHelloLayout = new javax.swing.GroupLayout(jDialogHello.getContentPane());
        jDialogHello.getContentPane().setLayout(jDialogHelloLayout);
        jDialogHelloLayout.setHorizontalGroup(
            jDialogHelloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jDialogHelloLayout.setVerticalGroup(
            jDialogHelloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTextFieldQuestionInstruction.setEditable(false);
        jTextFieldQuestionInstruction.setBackground(new java.awt.Color(255, 255, 255));
        jTextFieldQuestionInstruction.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        buttonGroupInstruction.add(jRadioButtonDCI);
        jRadioButtonDCI.setText("���������� DCI, ��������� �������");
        jRadioButtonDCI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonDCIActionPerformed(evt);
            }
        });

        buttonGroupInstruction.add(jRadioButtonClear);
        jRadioButtonClear.setText("�������� �������");
        jRadioButtonClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonClearActionPerformed(evt);
            }
        });

        buttonGroupInstruction.add(jRadioButtonAdd);
        jRadioButtonAdd.setText("�������� ��������� �������");
        jRadioButtonAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonAddActionPerformed(evt);
            }
        });

        jComboBoxPeople.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "" }));
        jComboBoxPeople.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBoxPeopleItemStateChanged(evt);
            }
        });
        jComboBoxPeople.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jComboBoxPeopleMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jComboBoxPeopleMousePressed(evt);
            }
        });
        jComboBoxPeople.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxPeopleActionPerformed(evt);
            }
        });
        jComboBoxPeople.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jComboBoxPeopleKeyPressed(evt);
            }
        });
        jComboBoxPeople.addVetoableChangeListener(new java.beans.VetoableChangeListener() {
            public void vetoableChange(java.beans.PropertyChangeEvent evt)throws java.beans.PropertyVetoException {
                jComboBoxPeopleVetoableChange(evt);
            }
        });

        jButtonGoGo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGoGoActionPerformed(evt);
            }
        });

        jLabelPicture.setIcon(new javax.swing.ImageIcon("D:\\Users\\Kseny\\OneDrive\\���������\\NetBeansProjects\\KondrashkinaLab2\\build\\classes\\kondrashkinalab6\\Emma.png")); // NOI18N

        jButtonExit.setText("�����");
        jButtonExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExitActionPerformed(evt);
            }
        });

        buttonGroupInstruction.add(jRadioButtonSeeList);
        jRadioButtonSeeList.setText("���������� ������ ����������");

        buttonGroupInstruction.add(jRadioButtonBorn);
        jRadioButtonBorn.setText("������ ��������");
        jRadioButtonBorn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonBornActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jRadioButtonBorn)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jComboBoxPeople, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jTextFieldQuestionInstruction)
                                .addComponent(jRadioButtonDCI, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                                .addComponent(jRadioButtonClear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jRadioButtonAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButtonGoGo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jRadioButtonSeeList))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButtonExit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabelPicture, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jTextFieldQuestionInstruction, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabelPicture)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonExit))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jComboBoxPeople, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButtonDCI)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jRadioButtonClear)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jRadioButtonAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jRadioButtonSeeList)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jRadioButtonBorn)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonGoGo, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jDialogInstructionLayout = new javax.swing.GroupLayout(jDialogInstruction.getContentPane());
        jDialogInstruction.getContentPane().setLayout(jDialogInstructionLayout);
        jDialogInstructionLayout.setHorizontalGroup(
            jDialogInstructionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDialogInstructionLayout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jDialogInstructionLayout.setVerticalGroup(
            jDialogInstructionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        jTextFieldName.setEditable(false);
        jTextFieldName.setBackground(new java.awt.Color(255, 255, 255));

        jButtonCloseDCI.setText("���������");
        jButtonCloseDCI.setAutoscrolls(true);
        jButtonCloseDCI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCloseDCIActionPerformed(evt);
            }
        });

        jTextAreaInfoDCI.setEditable(false);
        jTextAreaInfoDCI.setBackground(new java.awt.Color(255, 255, 255));
        jTextAreaInfoDCI.setColumns(20);
        jTextAreaInfoDCI.setRows(5);
        jScrollPane1.setViewportView(jTextAreaInfoDCI);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 528, Short.MAX_VALUE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButtonCloseDCI, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextFieldName, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTextFieldName, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButtonCloseDCI)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jDialogDCIPersonLayout = new javax.swing.GroupLayout(jDialogDCIPerson.getContentPane());
        jDialogDCIPerson.getContentPane().setLayout(jDialogDCIPersonLayout);
        jDialogDCIPersonLayout.setHorizontalGroup(
            jDialogDCIPersonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jDialogDCIPersonLayout.setVerticalGroup(
            jDialogDCIPersonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jComboBoxFood.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "" }));

        jButtonGoGrCalory.setText("�����");
        jButtonGoGrCalory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGoGrCaloryActionPerformed(evt);
            }
        });

        jButtonExitToInstruction.setText("�����");
        jButtonExitToInstruction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExitToInstructionActionPerformed(evt);
            }
        });

        jTextFieldAskGrammCalory.setEditable(false);
        jTextFieldAskGrammCalory.setBackground(new java.awt.Color(255, 255, 255));

        buttonGroupGrCal.add(jRadioButtonGramm);
        jRadioButtonGramm.setText("������");
        jRadioButtonGramm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonGrammActionPerformed(evt);
            }
        });

        buttonGroupGrCal.add(jRadioButtonCalory);
        jRadioButtonCalory.setText("�������");

        jButtonBack.setText("�����");
        jButtonBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBackActionPerformed(evt);
            }
        });

        jTextAreaGrCal.setEditable(false);
        jTextAreaGrCal.setColumns(20);
        jTextAreaGrCal.setRows(5);
        jScrollPane2.setViewportView(jTextAreaGrCal);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jComboBoxFood, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextFieldAskGrammCalory)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jTextFieldNewGrCal, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButtonGoGrCalory, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonBack, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonExitToInstruction, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jRadioButtonGramm)
                        .addGap(46, 46, 46)
                        .addComponent(jRadioButtonCalory)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane2)
                    .addComponent(jTextFieldAskNewGrCal))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jComboBoxFood, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextFieldAskGrammCalory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButtonGramm)
                    .addComponent(jRadioButtonCalory))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextFieldAskNewGrCal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextFieldNewGrCal, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonGoGrCalory)
                    .addComponent(jButtonExitToInstruction)
                    .addComponent(jButtonBack))
                .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout jDialogAddLayout = new javax.swing.GroupLayout(jDialogAdd.getContentPane());
        jDialogAdd.getContentPane().setLayout(jDialogAddLayout);
        jDialogAddLayout.setHorizontalGroup(
            jDialogAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jDialogAddLayout.setVerticalGroup(
            jDialogAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTextFieldListPersonName.setEditable(false);
        jTextFieldListPersonName.setBackground(new java.awt.Color(255, 255, 255));

        jTextAreaRacion.setEditable(false);
        jTextAreaRacion.setBackground(new java.awt.Color(255, 255, 255));
        jTextAreaRacion.setColumns(20);
        jTextAreaRacion.setRows(5);
        jScrollPane3.setViewportView(jTextAreaRacion);

        jButtonBackFromList.setText("���������");
        jButtonBackFromList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBackFromListActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 528, Short.MAX_VALUE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldListPersonName, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButtonBackFromList, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTextFieldListPersonName, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButtonBackFromList)
                .addContainerGap())
        );

        javax.swing.GroupLayout jDialogSeeListLayout = new javax.swing.GroupLayout(jDialogSeeList.getContentPane());
        jDialogSeeList.getContentPane().setLayout(jDialogSeeListLayout);
        jDialogSeeListLayout.setHorizontalGroup(
            jDialogSeeListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDialogSeeListLayout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jDialogSeeListLayout.setVerticalGroup(
            jDialogSeeListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTextField1.setEditable(false);
        jTextField1.setBackground(new java.awt.Color(255, 255, 255));
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField1.setText("������� ���������:");

        jButtonCreate.setText("�������");
        jButtonCreate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCreateActionPerformed(evt);
            }
        });

        jTextField2.setEditable(false);
        jTextField2.setBackground(new java.awt.Color(255, 255, 255));
        jTextField2.setText("���");

        jTextField4.setEditable(false);
        jTextField4.setBackground(new java.awt.Color(255, 255, 255));
        jTextField4.setText("����");

        jTextField6.setEditable(false);
        jTextField6.setBackground(new java.awt.Color(255, 255, 255));
        jTextField6.setText("���");

        jTextField3.setEditable(false);
        jTextField3.setBackground(new java.awt.Color(255, 255, 255));
        jTextField3.setText("���");

        buttonGroupGender.add(jRadioButtonMale);
        jRadioButtonMale.setText("�������");

        buttonGroupGender.add(jRadioButtonFemale);
        jRadioButtonFemale.setText("�������");

        jSlider2.setMaximum(220);
        jSlider2.setValue(160);
        jSlider2.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSlider2StateChanged(evt);
            }
        });

        jSlider3.setMaximum(150);
        jSlider3.setMinimum(5);
        jSlider3.setValue(60);
        jSlider3.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSlider3StateChanged(evt);
            }
        });

        jTextField5.setEditable(false);
        jTextField5.setBackground(new java.awt.Color(255, 255, 255));
        jTextField5.setText("����������� ����������");

        buttonGroupActivity.add(jRadioButton1);
        jRadioButton1.setText("1");

        buttonGroupActivity.add(jRadioButton2);
        jRadioButton2.setText("2");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });

        buttonGroupActivity.add(jRadioButton3);
        jRadioButton3.setText("3");

        buttonGroupActivity.add(jRadioButton4);
        jRadioButton4.setText("4");

        buttonGroupActivity.add(jRadioButton5);
        jRadioButton5.setText("5");

        buttonGroupActivity.add(jRadioButton6);
        jRadioButton6.setText("6");

        jTextField7.setEditable(false);
        jTextField7.setBackground(new java.awt.Color(255, 255, 255));
        jTextField7.setText("�������");

        jSlider4.setMinorTickSpacing(1);
        jSlider4.setValue(20);
        jSlider4.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSlider4StateChanged(evt);
            }
        });
        jSlider4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jSlider4MouseClicked(evt);
            }
        });

        jLabel1.setText("0");

        jLabel2.setText("100");

        jLabel3.setText("0");

        jLabel4.setText("220");

        jLabel5.setText("5");

        jLabel6.setText("150");

        jButton1.setText("�����");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabelAge.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelAge.setText("20");

        jLabelHeight.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelHeight.setText("160");

        jLabelWeight.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelWeight.setText("60");

        buttonGroupActivity.add(jRadioButton7);
        jRadioButton7.setText("0");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField1)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jTextField7, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(jTextField3, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField6, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField4, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButtonCreate, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldAnswerName)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                                .addComponent(jRadioButtonFemale, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jRadioButtonMale, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel7Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jSlider4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabelAge, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(119, 119, 119)))
                                .addComponent(jLabel2))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel7Layout.createSequentialGroup()
                                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel7Layout.createSequentialGroup()
                                                .addComponent(jSlider2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                                                .addGap(0, 0, Short.MAX_VALUE)
                                                .addComponent(jLabelHeight, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(118, 118, 118)))
                                        .addComponent(jLabel4))
                                    .addGroup(jPanel7Layout.createSequentialGroup()
                                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel7Layout.createSequentialGroup()
                                                .addComponent(jSlider3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                                                .addGap(0, 0, Short.MAX_VALUE)
                                                .addComponent(jLabelWeight, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(117, 117, 117)))
                                        .addComponent(jLabel6))))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jRadioButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jRadioButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jRadioButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jRadioButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jRadioButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(jRadioButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jRadioButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextFieldAnswerName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextField7)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabelAge)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jSlider4, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jRadioButtonMale)
                    .addComponent(jRadioButtonFemale))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextField4)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabelHeight)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jSlider2, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabelWeight)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jSlider3, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(13, 13, 13)))
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jRadioButton1)
                    .addComponent(jRadioButton2)
                    .addComponent(jRadioButton3)
                    .addComponent(jRadioButton4)
                    .addComponent(jRadioButton5)
                    .addComponent(jRadioButton6)
                    .addComponent(jRadioButton7))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButtonCreate)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jDialogBornLayout = new javax.swing.GroupLayout(jDialogBorn.getContentPane());
        jDialogBorn.getContentPane().setLayout(jDialogBornLayout);
        jDialogBornLayout.setHorizontalGroup(
            jDialogBornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jDialogBornLayout.setVerticalGroup(
            jDialogBornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jButtonStart.setText("START");
        jButtonStart.setPreferredSize(new java.awt.Dimension(300, 60));
        jButtonStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonStartActionPerformed(evt);
            }
        });

        jButtonBye.setText("GOOD BYE");
        jButtonBye.setMaximumSize(new java.awt.Dimension(300, 60));
        jButtonBye.setPreferredSize(new java.awt.Dimension(300, 60));
        jButtonBye.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonByeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(132, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButtonBye, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonStart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(108, 108, 108))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addComponent(jButtonStart, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButtonBye, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(96, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    void clearButton (){
        jRadioButtonAdd.setSelected(false);
        jRadioButtonClear.setSelected(false);
        jRadioButtonDCI.setSelected(false);       
    }
    public void clearCalory(int i){
        people.setPersonPrevCalory(i, people.getCalories(i));
        people.clearPersonCalory(i);
        allLunch.get(i).changeWeight( 0);        
    }
    
        //this.NextStepInstruction();
    private void jRadioButtonHelloYesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonHelloYesActionPerformed
        // TODO add your handling code here:
        if (all_food.size()==0){
            this.readFile();
            this.setPeopleLunch();
            this.FirstCount();
        }
        jDialogHello.dispose();
        jDialogInstruction.setSize(560,350);
        jDialogInstruction.setLocationRelativeTo(null);
        jDialogInstruction.setVisible(rootPaneCheckingEnabled);
        jDialogInstruction.pack();
        jTextFieldQuestionInstruction.setText("��� ������ ������� ������?");
        getNames(jComboBoxPeople);    
        jButtonGoGo.setText("�������!");
        //this.NextStepInstruction();
    }//GEN-LAST:event_jRadioButtonHelloYesActionPerformed

    private void jRadioButtonHelloNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonHelloNoActionPerformed
        // TODO add your handling code here:
        jDialogHello.dispose();
    }//GEN-LAST:event_jRadioButtonHelloNoActionPerformed

    private void jButtonStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonStartActionPerformed
        // TODO add your handling code here:
        jDialogHello.setSize(570,350);
        jDialogHello.setLocationRelativeTo(null);
        jDialogHello.setVisible(rootPaneCheckingEnabled);
        jTextFieldDefaultText.setText("������-������!\n������ �������� � ������?");
        jDialogHello.pack();
        jDialogHello.setVisible(rootPaneCheckingEnabled);
        //jButtonStart.hide();
        jButtonBye.setVisible(rootPaneCheckingEnabled);
    }//GEN-LAST:event_jButtonStartActionPerformed

    private void jTextFieldDefaultTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldDefaultTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldDefaultTextActionPerformed

    private void jRadioButtonDCIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonDCIActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jRadioButtonDCIActionPerformed

    private void jRadioButtonClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonClearActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButtonClearActionPerformed

    private void jRadioButtonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonAddActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButtonAddActionPerformed

    String getRacion(int i){
        String res ="";
        res += "������:\n";
        for (int k = 0; k < all_food.size(); ++k){
            
            if (allLunch.get(i).getCaloryMeal(k) != 0) {
            res += String.format("(%d) %s: %d gr; %.3f ccal\n", k+1,
                    allLunch.get(i).getNameMeal(k), allLunch.get(i).getWeightMeal(k),
                    allLunch.get(i).getCaloryMeal(k));
            System.out.println(k);
            }
        }
        return res;
    }
    private void jButtonGoGoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGoGoActionPerformed
        // TODO add your handling code here:
        clearButton();
        if (jRadioButtonDCI.isSelected()){
            int id = people.findName(String.valueOf(jComboBoxPeople.getSelectedItem()));   
            printDifDCICal(id);
            jDialogDCIPerson.setSize(570,350);
            jDialogDCIPerson.setLocationRelativeTo(null);
            jDialogDCIPerson.setVisible(rootPaneCheckingEnabled);
            jDialogDCIPerson.pack();
            jRadioButtonDCI.setSelected(false); 
        } else if (jRadioButtonClear.isSelected()){
            int id = people.findName(String.valueOf(jComboBoxPeople.getSelectedItem())); 
            this.clearCalory(id);
            JOptionPane.showMessageDialog(null,"�������� ��������� ������ ������� :)",
                            "Whoaho",JOptionPane.INFORMATION_MESSAGE);
            jRadioButtonClear.setSelected(false);        
        } else if (jRadioButtonAdd.isSelected()){
            step = 0;
            jDialogAdd.setSize(570,350);
            jDialogAdd.setLocationRelativeTo(null);
            jDialogAdd.setVisible(rootPaneCheckingEnabled);
            jTextFieldAskGrammCalory.setVisible(rootPaneCheckingEnabled);
            jRadioButtonGramm.setVisible(rootPaneCheckingEnabled);
            jRadioButtonCalory.setVisible(rootPaneCheckingEnabled);
            jTextFieldAskNewGrCal.hide();
            jTextFieldNewGrCal.hide();
            jTextAreaGrCal.setText("��������������� ������� ���� ������������ ���������.\n������� � ���������� ���� �� ������: �����.");
            getFoodNames(jComboBoxFood);
            jTextFieldAskGrammCalory.setText("������ �����������, ����� ������ ���������:");
            jRadioButtonAdd.setSelected(false);  
        } else if (jRadioButtonSeeList.isSelected()){
            int id = people.findName(String.valueOf(jComboBoxPeople.getSelectedItem()));
            String racion = getRacion(id);
            jTextFieldListPersonName.setText(String.valueOf(jComboBoxPeople.getSelectedItem()));
            jTextAreaRacion.setText(racion);
            jDialogSeeList.setSize(570,350);
            jDialogSeeList.setLocationRelativeTo(null);
            jDialogSeeList.setVisible(rootPaneCheckingEnabled);
        } else if (jRadioButtonBorn.isSelected()){
            jRadioButton1.setSelected(rootPaneCheckingEnabled);
            jRadioButtonMale.setSelected(rootPaneCheckingEnabled);
            jDialogBorn.setSize(570,350);
            jDialogBorn.setLocationRelativeTo(null);
            jDialogBorn.setVisible(rootPaneCheckingEnabled);
            jTextFieldAnswerName.setText("");
            jLabelAge.setText("20");
            jLabelHeight.setText("160");
            jLabelWeight.setText("60");
        } else {
            JOptionPane.showMessageDialog(null,"�� ������� �������� ...",
                            "Ooops",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButtonGoGoActionPerformed

    private void jButtonCloseDCIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCloseDCIActionPerformed
        // TODO add your handling code here:
        jDialogDCIPerson.dispose();
        clearButton();
    }//GEN-LAST:event_jButtonCloseDCIActionPerformed

    private void jButtonByeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonByeActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(null,"����-����!\n����������� ������ :)",
                            "Whoaho",JOptionPane.INFORMATION_MESSAGE);
        
        jDialogAdd.dispose();
        jDialogSeeList.dispose();
        jDialogInstruction.dispose();
        jDialogDCIPerson.dispose();
        jDialogHello.dispose();
        dispose();
    }//GEN-LAST:event_jButtonByeActionPerformed

    private void jComboBoxPeopleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxPeopleActionPerformed
        // TODO add your handling code here:        
    }//GEN-LAST:event_jComboBoxPeopleActionPerformed

    private void jComboBoxPeopleItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBoxPeopleItemStateChanged
        // TODO add your handling code here:
        if (jComboBoxPeople.getItemCount() == people.size()) {
         
            switch(String.valueOf(jComboBoxPeople.getSelectedItem())){
                case "����" -> {
                    ImageIcon icon = new ImageIcon("D:\\Users\\Kseny\\OneDrive\\���������\\NetBeansProjects\\KondrashkinaLab2\\build\\classes\\kondrashkinalab6\\Emma.png");
                    jLabelPicture.setIcon(icon);
                    System.out.println("Emma");
                }
                case "����" -> {
                    ImageIcon icon = new ImageIcon("D:\\Users\\Kseny\\OneDrive\\���������\\NetBeansProjects\\KondrashkinaLab2\\build\\classes\\kondrashkinalab6\\Ruta.png");
                    jLabelPicture.setIcon(icon);
                    System.out.println("Ruta");
                }
                case "����" -> {
                    ImageIcon icon = new ImageIcon("D:\\Users\\Kseny\\OneDrive\\���������\\NetBeansProjects\\KondrashkinaLab2\\build\\classes\\kondrashkinalab6\\Liam.png");
                    jLabelPicture.setIcon(icon);
                    System.out.println("Liam");
                }
                case "�����" -> {
                    ImageIcon icon = new ImageIcon("D:\\Users\\Kseny\\OneDrive\\���������\\NetBeansProjects\\KondrashkinaLab2\\build\\classes\\kondrashkinalab6\\Jake.png");
                    jLabelPicture.setIcon(icon);
                    System.out.println("Jake");
                }
                default -> {
                    int id = people.findName(String.valueOf(jComboBoxPeople.getSelectedItem()));
                    if (people.getSex(id)) {
                        ImageIcon icon = new ImageIcon("D:\\Users\\Kseny\\OneDrive\\���������\\NetBeansProjects\\KondrashkinaLab2\\build\\classes\\kondrashkinalab6\\Girl.png");
                        jLabelPicture.setIcon(icon);
                    } else {
                        ImageIcon icon = new ImageIcon("D:\\Users\\Kseny\\OneDrive\\���������\\NetBeansProjects\\KondrashkinaLab2\\build\\classes\\kondrashkinalab6\\Boy.png");
                        jLabelPicture.setIcon(icon);
                    }
                }
            }
        }
    }//GEN-LAST:event_jComboBoxPeopleItemStateChanged

    private void jComboBoxPeopleMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBoxPeopleMousePressed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jComboBoxPeopleMousePressed

    private void jComboBoxPeopleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBoxPeopleMouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jComboBoxPeopleMouseClicked

    private void jComboBoxPeopleKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jComboBoxPeopleKeyPressed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jComboBoxPeopleKeyPressed

    private void jComboBoxPeopleVetoableChange(java.beans.PropertyChangeEvent evt)throws java.beans.PropertyVetoException {//GEN-FIRST:event_jComboBoxPeopleVetoableChange
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jComboBoxPeopleVetoableChange

    private void jButtonExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExitActionPerformed
        // TODO add your handling code here:
        jDialogInstruction.dispose();
    }//GEN-LAST:event_jButtonExitActionPerformed

    private void jRadioButtonGrammActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonGrammActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jRadioButtonGrammActionPerformed
    int findFoodId (int i){
        int id = 0;
        Lunch temp_lunch = allLunch.get(i);
        String[] substr1 = String.valueOf(jComboBoxFood.getSelectedItem()).split(":");
        String idName = substr1[0];
        System.out.println(idName);
        int f_id = idName.indexOf(' ');
        String substr = idName.substring(f_id+1);
        System.out.println(substr);
        return temp_lunch.findMeal(substr);
    }
    int findFoodIdInAll (int p, int id){
        
        for (int i = 0; i < all_food.size(); ++i){
            System.out.println(")");
            System.out.println(i);
            if (allLunch.get(p).getNameMeal(id).equals(all_food.get(i).getName())){
                return i;
            }
        }
        return -1;
    }
    public boolean ChangeGramm(int i, int id){
        System.out.println("����� ����� ����� ��� (� �������)?\n���� ������ �������� ���� ����� �� ������� ����� 0:");
        
        double gramm;
        
        try {
            gramm = Double.parseDouble(jTextFieldNewGrCal.getText());
            
            if (gramm < 0) {
                throw new NegativeException();
            } else {
                people.setPersonPrevCalory(i, people.getCalories(i));
                if (allLunch.get(i).getWeightMeal(id) == 0){
                    people.setPersonCalory(i, allLunch.get(i).changeWeight(id, (int)gramm), true);
                } else {
                    people.setPersonCalory(i, allLunch.get(i).changeWeight(id, (int)gramm));
                }
                System.out.println(allLunch.get(i).getNameMeal(i));
                System.out.println(allLunch.get(i).getWeightMeal(i));
            }
            System.out.println(gramm);
            jTextFieldNewGrCal.setText("");
            return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                            String.format("���-�� �� ��� � ��������� ���������: %s\n", e.getMessage()),
                            "Ooops",JOptionPane.ERROR_MESSAGE);
            jTextFieldNewGrCal.setText("");
            return false;
            
        }           
    }
    public boolean ChangeCal(int i, int  id){
        System.out.println("����� ����� ����� ������������ (� ����)?\n���� ������ �������� ���� ����� �� ������ ����� 0:");
        
        double calory;        
        try {
            calory = Double.parseDouble(jTextFieldNewGrCal.getText());
            if (calory < 0) {
                throw new NegativeException();
            } else {
                people.setPersonPrevCalory(i, people.getCalories(i));
                if (allLunch.get(i).getWeightMeal(id) == 0){
                    people.setPersonCalory(i, allLunch.get(i).changeWeight(id, calory), true);
                } else {
                    people.setPersonCalory(i, allLunch.get(i).changeWeight(id, calory));
                }
            }
            return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                            String.format("���-�� �� ��� � ��������� ���������: %s\n", e.getMessage()),
                            "Ooops",JOptionPane.ERROR_MESSAGE);
            jTextFieldNewGrCal.setText("");
            return false;
        }        
    }
    private void jButtonGoGrCaloryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGoGrCaloryActionPerformed
        // TODO add your handling code here:
        System.out.println(step);
        switch(step){
            case 0:                
                if (jRadioButtonGramm.isSelected()){
                    jTextFieldAskNewGrCal.setVisible(rootPaneCheckingEnabled);
                    jTextFieldNewGrCal.setVisible(rootPaneCheckingEnabled);
                    jTextFieldAskGrammCalory.hide();
                    jRadioButtonGramm.hide();
                    jRadioButtonCalory.hide(); 
                    jTextFieldAskNewGrCal.setText("����� ����� ����� ��� (� �������)?");
                    step = 1;
                } else if (jRadioButtonCalory.isSelected()){
                    jTextFieldAskNewGrCal.setVisible(rootPaneCheckingEnabled);
                    jTextFieldNewGrCal.setVisible(rootPaneCheckingEnabled);
                    jTextFieldAskGrammCalory.hide();
                    jRadioButtonGramm.hide();
                    jRadioButtonCalory.hide();
                    jTextFieldAskNewGrCal.setText("����� ����� ����� ������������ (� ����)?");
                    step = 1;
                } else {
                    JOptionPane.showMessageDialog(null,
                            String.format(" �� ������� �����������: ������/�������"),
                            "Ooops",JOptionPane.ERROR_MESSAGE);
                }
                break;
            case 1:
                int i = people.findName(String.valueOf(jComboBoxPeople.getSelectedItem()));
                int id = findFoodId(i);
                System.out.println(id);
                System.out.println("....");
                if (jRadioButtonGramm.isSelected()){
                    
                    if (!ChangeGramm(i, id)){ break;}
                    JOptionPane.showMessageDialog(null,
                            String.format("��������� ����������: %s\n", all_food.get(findFoodIdInAll(i,id)).getName()),
                            "Ooops",JOptionPane.INFORMATION_MESSAGE);
                    jTextFieldNewGrCal.setText("");
                    jDialogAdd.dispose();
                    step = 2;
                } else if (jRadioButtonCalory.isSelected()){
                    if (!ChangeCal(i, id)){break;}
                    JOptionPane.showMessageDialog(null,
                            String.format("��������� ����������: %s\n", all_food.get(findFoodIdInAll(i,id)).getName()),
                            "Ooops",JOptionPane.INFORMATION_MESSAGE);
                    jTextFieldNewGrCal.setText("");
                    jDialogAdd.dispose();
                    step = 2;
                } else {
                    JOptionPane.showMessageDialog(null,
                            String.format(" �� ������� �����������: ������/�������"),
                            "Ooops",JOptionPane.ERROR_MESSAGE);
                }
                break;
        }
    }//GEN-LAST:event_jButtonGoGrCaloryActionPerformed

    private void jButtonBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBackActionPerformed
        // TODO add your handling code here:
        System.out.println(step);
        switch(step){
            case 0: 
                JOptionPane.showMessageDialog(null,
                            String.format("���� ��� ����������� ����"),
                            "Hmmm",JOptionPane.INFORMATION_MESSAGE);
            case 1:
                jTextFieldAskGrammCalory.setVisible(rootPaneCheckingEnabled);
                jRadioButtonGramm.setVisible(rootPaneCheckingEnabled);
                jRadioButtonCalory.setVisible(rootPaneCheckingEnabled);
                jTextFieldAskNewGrCal.hide();
                jTextFieldNewGrCal.setText("");
                jTextFieldNewGrCal.hide();
                jTextAreaGrCal.setText("��������������� ������� ���� ������������ ���������.\n������� � ���������� ���� �� ������: �����.");
                getFoodNames(jComboBoxFood);
                jTextFieldAskGrammCalory.setText("������ �����������, ����� ������ ���������:");
                jRadioButtonGramm.setSelected(false);
                jRadioButtonCalory.setSelected(false);
                step = 0;
                break;            
        }
    }//GEN-LAST:event_jButtonBackActionPerformed

    private void jButtonExitToInstructionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExitToInstructionActionPerformed
        // TODO add your handling code here:
        jDialogAdd.dispose();
        jTextFieldNewGrCal.setText("");
        jRadioButtonGramm.setSelected(false);
        jRadioButtonCalory.setSelected(false);
    }//GEN-LAST:event_jButtonExitToInstructionActionPerformed

    private void jButtonBackFromListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBackFromListActionPerformed
        // TODO add your handling code here:
        jDialogSeeList.dispose();
        jTextAreaRacion.setText("");
        jTextFieldListPersonName.setText("");
    }//GEN-LAST:event_jButtonBackFromListActionPerformed

    private void jRadioButtonBornActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonBornActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButtonBornActionPerformed

    private void jButtonCreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCreateActionPerformed
        // TODO add your handling code here:
        int i = people.size();
        String name = jTextFieldAnswerName.getText();
        if (name.equals("")){
            JOptionPane.showMessageDialog(null,
                            String.format("������ ��� ������ :("),
                            "Ooops",JOptionPane.ERROR_MESSAGE);
        } else {
            double height = jSlider2.getValue();
            double weight = jSlider3.getValue();
            int age = jSlider4.getValue();
            boolean sex = true;
            if (jRadioButtonMale.isSelected()){
                sex = false;
            }
            int activ = 0;
            
            if (jRadioButton1.isSelected()){
                activ = 1;
            } else if (jRadioButton2.isSelected()){
                activ = 2;
            } else if (jRadioButton3.isSelected()){
                activ = 3;
            } else if (jRadioButton4.isSelected()){
                activ = 4;
            } else if (jRadioButton5.isSelected()){
                activ = 5;
            } else if (jRadioButton6.isSelected()){
                activ = 6;
            }
            //String name, double height, double weight, int age, boolean sex, int coefActivity
            Person p = new Person(name, height, weight, age, sex, activ);
            people.addPerson(p);
            Lunch lunchPerson = new Lunch(0, all_food.size());
        
            for (int food_id = 0; food_id < all_food.size(); ++food_id){
                lunchPerson.addMeal(food_id, 0, all_food);
            }
            people.countAllDCI();
            allLunch.add(lunchPerson);
            //System.out.println(people.size()-1);
            //System.out.println(allLunch.size()-1);
            double resCalories = allLunch.get(people.size()-1).countResCalories();
            people.setPersonCalory(people.size()-1,resCalories, true);
            getNames(jComboBoxPeople);
            JOptionPane.showMessageDialog(null,
                            String.format("� %s � � �������!", name),
                            "Whoah",JOptionPane.INFORMATION_MESSAGE);
            jDialogBorn.dispose();
            jTextFieldAnswerName.setText("");
            jLabelAge.setText("20");
            jLabelHeight.setText("160");
            jLabelWeight.setText("60");
        }
    }//GEN-LAST:event_jButtonCreateActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        jTextFieldAnswerName.setText("");
        jLabelAge.setText("20");
        jLabelHeight.setText("160");
        jLabelWeight.setText("60");
        jDialogBorn.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jSlider4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jSlider4MouseClicked
        // TODO add your handling code here:
        //jLabelAge.setText(String.valueOf(jSlider4.getValue()));
    }//GEN-LAST:event_jSlider4MouseClicked

    private void jSlider4StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSlider4StateChanged
        // TODO add your handling code here:
        jLabelAge.setText(String.valueOf(jSlider4.getValue()));
    }//GEN-LAST:event_jSlider4StateChanged

    private void jSlider2StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSlider2StateChanged
        // TODO add your handling code here:
        jLabelHeight.setText(String.valueOf(jSlider2.getValue()));
    }//GEN-LAST:event_jSlider2StateChanged

    private void jSlider3StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSlider3StateChanged
        // TODO add your handling code here:
        jLabelWeight.setText(String.valueOf(jSlider3.getValue()));
    }//GEN-LAST:event_jSlider3StateChanged

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UserWorkJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UserWorkJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UserWorkJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UserWorkJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                UserWorkJFrame myJF = new UserWorkJFrame();
                myJF.setSize(570,350);
                myJF.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroupActivity;
    private javax.swing.ButtonGroup buttonGroupGender;
    private javax.swing.ButtonGroup buttonGroupGrCal;
    private javax.swing.ButtonGroup buttonGroupHello;
    private javax.swing.ButtonGroup buttonGroupInstruction;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButtonBack;
    private javax.swing.JButton jButtonBackFromList;
    private javax.swing.JButton jButtonBye;
    private javax.swing.JButton jButtonCloseDCI;
    private javax.swing.JButton jButtonCreate;
    private javax.swing.JButton jButtonExit;
    private javax.swing.JButton jButtonExitToInstruction;
    private javax.swing.JButton jButtonGoGo;
    private javax.swing.JButton jButtonGoGrCalory;
    private javax.swing.JButton jButtonStart;
    private javax.swing.JComboBox<String> jComboBoxFood;
    private javax.swing.JComboBox<String> jComboBoxPeople;
    private javax.swing.JDialog jDialogAdd;
    private javax.swing.JDialog jDialogBorn;
    private javax.swing.JDialog jDialogDCIPerson;
    private javax.swing.JDialog jDialogHello;
    private javax.swing.JDialog jDialogInstruction;
    private javax.swing.JDialog jDialogSeeList;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabelAge;
    private javax.swing.JLabel jLabelHeight;
    private javax.swing.JLabel jLabelPicture;
    private javax.swing.JLabel jLabelWeight;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JRadioButton jRadioButton5;
    private javax.swing.JRadioButton jRadioButton6;
    private javax.swing.JRadioButton jRadioButton7;
    private javax.swing.JRadioButton jRadioButtonAdd;
    private javax.swing.JRadioButton jRadioButtonBorn;
    private javax.swing.JRadioButton jRadioButtonCalory;
    private javax.swing.JRadioButton jRadioButtonClear;
    private javax.swing.JRadioButton jRadioButtonDCI;
    private javax.swing.JRadioButton jRadioButtonFemale;
    private javax.swing.JRadioButton jRadioButtonGramm;
    private javax.swing.JRadioButton jRadioButtonHelloNo;
    private javax.swing.JRadioButton jRadioButtonHelloYes;
    private javax.swing.JRadioButton jRadioButtonMale;
    private javax.swing.JRadioButton jRadioButtonSeeList;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSlider jSlider1;
    private javax.swing.JSlider jSlider2;
    private javax.swing.JSlider jSlider3;
    private javax.swing.JSlider jSlider4;
    private javax.swing.JTextArea jTextAreaGrCal;
    private javax.swing.JTextArea jTextAreaInfoDCI;
    private javax.swing.JTextArea jTextAreaRacion;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextFieldAnswerName;
    private javax.swing.JTextField jTextFieldAskGrammCalory;
    private javax.swing.JTextField jTextFieldAskNewGrCal;
    private javax.swing.JTextField jTextFieldDefaultText;
    private javax.swing.JTextField jTextFieldListPersonName;
    private javax.swing.JTextField jTextFieldName;
    private javax.swing.JTextField jTextFieldNewGrCal;
    private javax.swing.JTextField jTextFieldQuestionInstruction;
    // End of variables declaration//GEN-END:variables
}
