/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kondrashkinalab6;
import kondrashkinalab6.informationtolab6.*;
import java.util.ArrayList;
/**
 *
 * @author Kseny
 */
public class RandomChoice {
    public static int randomChoice(int size){
        int border_down = 0, border_up = size - 1;
        return (int)(Math.random() * (border_up-border_down) + border_down);
    }
    public static int randomChoiceWeight(){
        int border_down = 0, border_up = 300;
        return (int)(Math.random() * (border_up-border_down) + border_down);
    }
}
