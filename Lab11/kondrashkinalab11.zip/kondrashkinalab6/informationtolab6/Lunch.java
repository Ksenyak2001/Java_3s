/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kondrashkinalab6.informationtolab6;
import java.util.ArrayList;
/**
 *
 * @author Kseny
 */
public class Lunch {
    //int countMealLunch = 4, countMealDinner = 3, idFull = 0; 
    ArrayList<Food> meals;
    ArrayList<Integer> weightsMeal;
    public Lunch (int countMealLunch, int countMealDinner) {
        //this.countMealLunch = countMealLunch;
        //this.countMealDinner = countMealDinner;
        this.meals = new ArrayList<>();
        this.weightsMeal = new ArrayList<>();
    }
    public int size(){
        return meals.size();
    }
    public int findMeal(String name){
        System.out.println(meals.size());
        System.out.println("***");
        for (int i = 0; i < meals.size(); i++){
            System.out.println(meals.get(i).getName());
            if(name.equals(meals.get(i).getName())){
                return i;
            }
        }
        return 0;
    }
    public void addMeal(int i, int weight, ArrayList<Food> all_food){
        meals.add(all_food.get(i));
        weightsMeal.add(weight);        
    }
    public String getNameMeal(int i){
        return meals.get(i).getName();
    }
    public int getWeightMeal(int i){
        return weightsMeal.get(i);
    }
    public double getCaloryMeal(int i){
        return meals.get(i).CountCalories(weightsMeal.get(i));
    }    
    public double countResCalories(){
        /* ��� ���������� ���������� �����:
        int border_up = 200, border_down = -100;
        int [] weightsMeal = new int[countMealLunch+countMealDinner];*/        
        double resCalories = 0;
        //System.out.println("������:");
        for (int k = 0; k < meals.size(); ++k) {
            /*����� ��� ���������� ���������� �����:
            weightsMeal[k] = (int)(Math.random() * (border_up-border_down) + border_down);*/
            if (weightsMeal.get(k) > 0) {
                double tempCalory = meals.get(k).CountCalories(weightsMeal.get(k));
                //System.out.println(String.format("%s: %d ����� (%.2f ����);", 
                //            meals[k].getName(), weightsMeal[k], tempCalory));
                resCalories += tempCalory;
            }            
        }
        //System.out.println(String.format("�����: %.2f ����.\n", resCalories));
        return resCalories;
    }
    public double changeWeight(String foodName, int gramm){
        for (int i = 0; i < this.meals.size(); ++i){
            if (foodName.equals(meals.get(i).getName())){
                weightsMeal.set(i, gramm);
            }
        }
        return countResCalories();
    }
    public double changeWeight(int gramm){
        for (int i = 0; i < this.meals.size(); ++i){
            this.weightsMeal.set(i, gramm);
        }
        return countResCalories();
    }
    public double changeWeight(int foodName, int gramm){
        weightsMeal.set(foodName, gramm);
        return countResCalories();
    }
    public double changeWeight(int foodName, double cal){
        double gramm = cal/meals.get(foodName).CountCalories();
        weightsMeal.set(foodName,(int)gramm);
        return countResCalories();
    }
    public boolean checkId(String foodName){
        for (int i = 0; i < this.meals.size();++i){
            if (meals.get(i).getName().equals(foodName)){
                return false;
            }
        }
        return true;
    }
}
