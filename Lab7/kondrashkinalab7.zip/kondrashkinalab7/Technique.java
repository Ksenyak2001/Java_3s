/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kondrashkinalab7;

/**
 *
 * @author Kseny
 */
public abstract class Technique implements Breaking{
    boolean is_work = true;
    public String tellIsWork (){
        return (is_work? "��������":"������");
    }
    @Override
    public void breakTechnique(){
        printInfoOfBreak();
        this.is_work=false;
    }
    public void fixTechnique(){
        this.is_work=true;
    }
    protected void printInfoOfBreak(){
        System.out.println("������� ���������.");
    }
    abstract public String getName();
}
