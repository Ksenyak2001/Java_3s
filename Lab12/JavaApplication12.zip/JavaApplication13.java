/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication13;


import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * @author Kseny
 */
public class JavaApplication13 implements Runnable {
    private static class Resource {
    }

    private final Resource resource1 = new Resource();
    private final Resource resource2 = new Resource();
    private final ReentrantLock lock1 = new ReentrantLock();    
    private final ReentrantLock lock2 = new ReentrantLock();
    //private int timeWait = 100;
    private volatile boolean ind1 = true;
    private volatile boolean ind2 = true;
    private volatile boolean done1 = false;
    private volatile boolean done2 = false;
    
    private volatile int count1 = 0;
    private volatile int count2 = 0;
    
    public void doFirstTask() {
        //synchronized (lock1)
        while (lock1.isLocked()) {}
        lock1.lock();

        System.out.println(Thread.currentThread().getName()
                + " ����� ���-�� ������. ���� ��������� 2...");
        try { Thread.sleep(100); }
        catch (InterruptedException e) {                
            System.out.println(Thread.currentThread().getName() + " ���������");
        }
        //synchronized (lock2)
        try {

            if (lock2.isLocked()) { 
                throw new Exception ();
            } else 
            {
                lock1.unlock();
                System.out.println(Thread.currentThread().getName()
                        + " ������� ��������� 2.");
                System.out.println(Thread.currentThread().getName()
                        + " ������� ���� 1.\n");
            }
        } catch (Exception ex){
            System.out.println(Thread.currentThread().getName() + " ������ �����������");
            lock1.unlock();
        }
    }

    public void doSecondTask() {
        //synchronized (lock2) 
        while (lock2.isLocked()) {}
        lock2.lock();
        System.out.println(Thread.currentThread().getName()
                + " ����� ���-�� ������. ���� ��������� 1...");
        try { Thread.sleep(100); }
        catch (InterruptedException e) {                
            System.out.println(Thread.currentThread().getName() + " ���������");
        }
        //synchronized (resource1) 
        try
        {
            if (lock1.isLocked())
            {
                throw new Exception ();
            } else
            {
                lock2.unlock();
                System.out.println(Thread.currentThread().getName()
                    + " ������� ��������� 1.");
                System.out.println(Thread.currentThread().getName()
                    + " ������� ���� 2.\n");
            }
        } catch (Exception ex) {
            System.out.println(Thread.currentThread().getName() + " ������ �����������");
            lock2.unlock(); 
        }       
    }

    @Override
    public void run() {
        while (true){
            doFirstTask();
            doSecondTask();
        }
    }

    public static void main(String[] args) {
        JavaApplication13 work = new JavaApplication13();
        Thread one = new Thread(work, "����� 1");
        Thread two = new Thread(work, "����� 2");
        one.start();
        two.start();
    }
}