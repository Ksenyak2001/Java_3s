/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ekz;


import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * @author Kseny
 */
public class Ekz implements Runnable {
    private static class Resource {
    }

    private final Resource resource1 = new Resource();
    private final Resource resource2 = new Resource();
    private final ReentrantLock lock1 = new ReentrantLock();    
    private final ReentrantLock lock2 = new ReentrantLock();
  
    static volatile int count1 = 0;
    static int count2 = 0;
    static AtomicInteger atomicInteger = new AtomicInteger(0);
    
    public void doFirstTask() {
        while (lock1.isLocked()) {}
        lock1.lock();

        System.out.println(Thread.currentThread().getName()
                + " начал что-то делать. Ждет компонент 2...");
        try { Thread.sleep(100); }
        catch (InterruptedException e) {                
            System.out.println(Thread.currentThread().getName() + " прервался");
        }
        try {

            if (lock2.isLocked()) { 
                throw new Exception ();
            } else 
            {
                lock1.unlock();
                count1 += 1;                
                count2 += 1;
                System.out.println(Thread.currentThread().getName()
                        + " получил компонент 2.");
                System.out.println(Thread.currentThread().getName()
                        + " доделал дело 1.\n");
            }
        } catch (Exception ex){
            System.out.println(Thread.currentThread().getName() + " раньше освободился");
            lock1.unlock();
        }
    }

    public void doSecondTask() {
        while (lock2.isLocked()) {}
        lock2.lock();
        System.out.println(Thread.currentThread().getName()
                + " начал что-то делать. Ждет компонент 1...");
        try { Thread.sleep(100); }
        catch (InterruptedException e) {                
            System.out.println(Thread.currentThread().getName() + " прервался");
        } 
        try
        {
            if (lock1.isLocked())
            {
                throw new Exception ();
            } else
            {
                lock2.unlock();
                count1 += 1;                
                count2 += 1;
                System.out.println(Thread.currentThread().getName()
                    + " получил компонент 1.");
                System.out.println(Thread.currentThread().getName()
                    + " доделал дело 2.\n");
            }
        } catch (Exception ex) {
            System.out.println(Thread.currentThread().getName() + " раньше освободился");
            lock2.unlock(); 
        }       
    }
    
    public void doThirdTask() {
        synchronized (resource1) {
        System.out.println(Thread.currentThread().getName()
                + " начал что-то делать. Ждет компонент 2...");
        try { Thread.sleep(100); }
        catch (InterruptedException e) {                
            System.out.println(Thread.currentThread().getName() + " прервался");
        }
        synchronized (resource2){
            System.out.println(Thread.currentThread().getName()
                        + " получил компонент 2.");
            System.out.println(Thread.currentThread().getName()
                        + " доделал дело 1.\n");
        
            }
        }
    }
    
    public void doFourthTask() {
        synchronized (resource2) {
        System.out.println(Thread.currentThread().getName()
                + " начал что-то делать. Ждет компонент 1...");
        try { Thread.sleep(100); }
        catch (InterruptedException e) {                
            System.out.println(Thread.currentThread().getName() + " прервался");
        }
        
        synchronized (resource1){
            System.out.println(Thread.currentThread().getName()
                        + " получил компонент 1.");
            System.out.println(Thread.currentThread().getName()
                        + " доделал дело 2.\n");
        
            }
        }
    }
    
    public void doFifthTask() {
        if (lock1.isLocked()) {
            lock1.lock();

            System.out.println(Thread.currentThread().getName()
                    + " начал что-то делать. Ждет компонент 2...");
            try { Thread.sleep(100); }
            catch (InterruptedException e) {                
                System.out.println(Thread.currentThread().getName() + " прервался");
            }
            try {

                if (lock2.isLocked()) { 
                    throw new Exception ();
                } else 
                {
                    lock1.unlock();
                    System.out.println(Thread.currentThread().getName()
                            + " получил компонент 2.");
                    System.out.println(Thread.currentThread().getName()
                            + " доделал дело 1.\n");
                }
            } catch (Exception ex){
                System.out.println(Thread.currentThread().getName() + " раньше освободился");
                lock1.unlock();
            }
        }
        
    }

    public void doSixthTask() { 
        if (!lock2.isLocked()) {
            lock2.lock();
            System.out.println(Thread.currentThread().getName()
                    + " начал что-то делать. Ждет компонент 1...");
            try { Thread.sleep(100); }
            catch (InterruptedException e) {                
                System.out.println(Thread.currentThread().getName() + " прервался");
            }
            try
            {
                if (lock1.isLocked())
                {
                    throw new Exception ();
                } else
                {
                    lock2.unlock();
                    System.out.println(Thread.currentThread().getName()
                        + " получил компонент 1.");
                    System.out.println(Thread.currentThread().getName()
                        + " доделал дело 2.\n");
                }
            } catch (Exception ex) {
                System.out.println(Thread.currentThread().getName() + " раньше освободился");
                lock2.unlock(); 
            } 
        }
    }
    
    //Все философы покушали и выжили
    /*
    @Override
    public void run() {
        for (int j = 0; j < 100; j++){
            doFirstTask();
            doSecondTask();
        }
        
    }
    */
    
    //Ииии - все умерли :(
    @Override
    public void run() {
        for (int j = 0; j < 100; j++){
            doThirdTask();
            doFourthTask();
        }
    }
    
    
    //Одын, совсем одын голодный философ
    /*
    @Override
    public void run() {
        for (int j = 0; j < 100; j++){
            doFifthTask();
            doSixthTask();
        }
    }*/
    
    public static void main(String[] args) throws myException, Exception {
        for (int j = 0; j < 5000; j++){
            new MyThread().start();
        }
        Thread.sleep(2000);
        System.out.println(count1);
        
        try {
            throw new myException();
        } catch (myException e){
            System.out.println(e.toString());
        } catch (Exception e2){
            System.out.println(e2.toString());
        }
        
        for (int j = 0; j < 5000; j++){
            new MyThread2().start();
        }
        Thread.sleep(2000);
        System.out.println(atomicInteger.get());
        
        for (int j = 0; j < 5000; j++){
            new MyThread3().start();
        }              
        Thread.sleep(2000);
        System.out.println(count2);


        Ekz work = new Ekz();
        Thread one = new Thread(work, "Поток 1");
        Thread two = new Thread(work, "Поток 2");

        one.start();
        two.start();
    }
    
    static class MyThread extends Thread{
        @Override
        public void run(){
                count1++;
            }
        }
    static class MyThread2 extends Thread{
        @Override
        public void run(){
        atomicInteger.incrementAndGet();
        }
    }
    static class MyThread3 extends Thread{
        @Override
        public void run(){{
                count2++;
            }
        }
    }
}