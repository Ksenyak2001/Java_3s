package kondrashkinalab2;
import kondrashkinalab2.informationtolab2.*;
/**
 *
 * @author Ksenya Kondrashkina
 */
public class KondrashkinaLab2 {

    /*В классе main:
        a.создать 4 блюда через массив для обеда и 3 блюда для ужина;
        b.создать мужчину и женщину через массив;
        c.вывести значения DCI на экран для каждого человека;
        d.при условии, что все съели одинаковые порции, 
          просчитать, превысили ли норму питания для каждого человека 
          и вывести результат на экран.     
     */
    public static void main(String[] args) { 
        //a.создать 4 блюда через массив для обеда и 3 блюда для ужина;
        int countMealLunch = 4, countMealDinner = 3;
        Lunch todayLunch = new Lunch(countMealLunch, countMealDinner);
        
        //Обед : Салат Цезарь, Суп грибной, Картофельное пюре, Индейка жареная
        //Ужин : Морковь по-корейски, Роллы Филадельфия, Роллы Калифорния
        //int [] weightsMeal = {62, 120, 56, 47, 38, 52, 44};  
        todayLunch.addMeal(new Food("Салат Цезарь", 14.8, 
                24, 17.2), 62);
        todayLunch.addMeal(new Food("Суп грибной", 1.3,
                1.3, 1.8), 120);
        todayLunch.addMeal(new Food("Картофельное пюре", 2.1, 
                8.5, 4.6), 56);
        todayLunch.addMeal(new Food("Индейка жареная", 28, 
                0, 6), 47);
        todayLunch.addMeal(new Food("Морковь по-корейски", 0, 
                12.9, 9), 38);
        todayLunch.addMeal(new Food("Роллы Филадельфия", 390, 
                13.3, 23.4), 52);
        todayLunch.addMeal(new Food("Роллы Калифорния", 403, 
                14.5, 16.2), 44);
        
        //b.создать мужчину и женщину через массив;
        int countPerson = 2;
        TestPeople people = new TestPeople(countPerson);
        people.addPerson(new Person("Эмма", 164.8, 68, 19,
                true, 1));
        people.addPerson(new Person("Джейк", 187.3, 70.3, 40, 
                false, 5));
        //c.вывести значения DCI на экран для каждого человека;
        people.countAllDCI();
        //d.при условии, что все съели одинаковые порции,      
        //можно изменить вес продукта: changeWeight(String foodName, int gramm)
        todayLunch.changeWeight("Салат Цезарь", 86);
        
        //  просчитать, превысили ли норму питания для каждого человека 
        //  и вывести результат на экран. 
        double resCalories = todayLunch.countResCalories();
        people.checkDifference(resCalories);        
    } 
}
