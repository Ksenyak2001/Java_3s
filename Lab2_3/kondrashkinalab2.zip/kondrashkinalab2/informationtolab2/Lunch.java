/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kondrashkinalab2.informationtolab2;

/**
 *
 * @author Kseny
 */
public class Lunch {
    int countMealLunch = 4, countMealDinner = 3, idFull = 0; 
    Food[] meals;
    int[] weightsMeal;
    public Lunch (int countMealLunch, int countMealDinner) {
        this.countMealLunch = countMealLunch;
        this.countMealDinner = countMealDinner;
        this.meals = new Food[this.countMealLunch+this.countMealDinner];
        this.weightsMeal = new int[this.countMealLunch+this.countMealDinner];
    }
    public void addMeal(Food f, int weight){
        meals[idFull] = f;
        weightsMeal[idFull++] = weight;
    }
        
    public double countResCalories(){
        /* Для случайного заполнения весов:
        int border_up = 200, border_down = -100;
        int [] weightsMeal = new int[countMealLunch+countMealDinner];*/        
        double resCalories = 0;
        Person.ps.println("Всего было съедено:");
        for (int k = 0; k < meals.length; ++k) {
            /*Также для случайного заполнения весов:
            weightsMeal[k] = (int)(Math.random() * (border_up-border_down) + border_down);*/
            if (weightsMeal[k] > 0) {
                double tempCalory = meals[k].CountCalories(weightsMeal[k]);
                Person.ps.println(String.format("%s: %d грамм (%.2f ккал);", 
                            meals[k].getName(), weightsMeal[k], tempCalory));
                resCalories += tempCalory;
            }            
        }
        Person.ps.println(String.format("Итого: %.2f ккал.\n", resCalories));
        return resCalories;
    }
    
    public void changeWeight(String foodName, int gramm){
        for (int i = 0; i < this.meals.length; ++i){
            if (foodName.equals(meals[i].getName())){
                weightsMeal[i] = gramm;
            }
        }
    }
}
