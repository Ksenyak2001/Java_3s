/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kondrashkinalab2.informationtolab2;

/**
 *
 * @author Kseny
 */
public class TestPeople {
    int countPerson = 2, idFull = 0;
    Person[] people;
    public TestPeople (int countPerson) {
        this.countPerson = countPerson;
        this.people = new Person[this.countPerson];
    }
    public void addPerson (Person p){
        people[idFull++] = p;
    }
    public void countAllDCI() {
        for (Person p: people) {
            p.countDCI();
            p.printInfo();
        }
    }
    public void checkDifference(double resCalories){      
        for (Person p: people){
            p.setCalories(resCalories);
            p.countDifference();
        }
    }
}
