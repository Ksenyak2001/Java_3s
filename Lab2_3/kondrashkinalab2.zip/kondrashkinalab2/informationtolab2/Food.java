/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kondrashkinalab2.informationtolab2;

/**
 *
 * @author Kseny
 */
/* Для класса еда создать:
    a.свойства класса: Имя, Белки, Углеводы, Жиры;
    b.гет  функции на них;
    c.конструктор;
    d.функцию, которая будет считать калории.
*/
public class Food {
    //a.свойства класса: Имя, Белки, Углеводы, Жиры;
    private String name;
    private double proteins = 0,carbohydrates = 0, fats = 0;
    //c.конструктор;
    public Food () {};
    public Food (String name) {
        this.name = name;
    }
    public Food (String name, double proteins,double carbohydrates,double fats) {
        this.name = name;
        this.proteins = proteins;
        this.carbohydrates = carbohydrates;
        this.fats = fats;
    }
    //b.гет  функции на них;
    public String getName(){
        return name;
    }
    public double getProteins(){
        return proteins;
    }
    public double getCarbohydrates() {
        return carbohydrates;
    }
    public double getFats () {
        return fats;
    }
    //set функции
    public void setName(String name){
        this.name = name;
    }
    public void setProteins(double proteins){
        this.proteins = proteins;
    }
    public void setCarbohydrates(double carbohydrates) {
        this.carbohydrates = carbohydrates;
    }
    public void setFats (double fats) {
        this.fats = fats;
    }
    //d.функцию, которая будет считать калории
    public double CountCalories (int weight) {
        double coefProteins = 4.1, coefCarbohydrates = 4.1, coefFats = 9.29;
        int gramm = 100;
        return (proteins*coefProteins + 
                carbohydrates*coefCarbohydrates + fats*coefFats)/gramm * weight;
    }
}
