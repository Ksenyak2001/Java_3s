/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kondrashkinalab2.informationtolab2;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Kseny
 */
/* 5.Для класса человек создать:
    a.cвойства класса: имя, рост, вес, возраст, пол и номер коэффициента активности;
    b.гет функции на них. Создать сет функции на них;
    c.cет функция на номер коэффициента активности должна быть не меньше 0 и не больше 6;
    d.функцию получения коэффициента активности через switch;
    e.конструктор;
    f.функцию расчета DCI.
*/
public class Person {    
    public static PrintStream ps = System.out;
    private static void setPrintStream(){
        try {
            ps = new PrintStream(System.out, true, "utf-8");
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(Person.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    //a.cвойства класса: имя, рост, вес, возраст, пол и номер коэффициента активности;
    private String name = "", infoAboutActivity = "";
    private double height = 0, weight = 0, activity = 0;
    private int age = 0;
    private double DCI = 0, totalCalories = 0;
    // 1 - девушка, 0 - парень
    private boolean sex = false;
    //e.конструктор;
    public Person () {setPrintStream();};
    public Person(String name) {
        this.name = name;
        setPrintStream();
    }
    public Person (String name, double height, double weight, int age, 
            boolean sex, int coefActivity){
        this.name = name;
        this.height = height;
        this.weight = weight;
        this.age = age;
        this.sex = sex;
        setActivity(coefActivity);
        setPrintStream();
    }
    //b.гет функции на них.
    public String getName(){
        return name;
    }
    public double getHeight() {
        return height;
    }
    public double getWeight() {
        return weight;
    }
    public double getActivity() {
        return activity;
    }
    public int getAge() {
        return age;
    }
    public boolean getSex() {
        return sex;
    }
    //Создать сет функции на них;
    public void setName(String name){
        this.name = name;
    }
    public void setHeight(double height) {
        this.height = height;
    }
    public void setWeight(double weight) {
        this.weight = weight;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public void setSex(boolean sex) {
        this.sex = sex;
    }
    //c.cет функция на номер коэффициента активности должна быть не меньше 0 и не больше 6;
    //d.функцию получения коэффициента активности через switch;
    public final void setActivity(int coefActivity) {
        try {
        switch (coefActivity) {
            case 0 -> {
                this.activity = 1.2;
                this.infoAboutActivity = "Физическая нагрузка отсутствует или минимальная";
            }
            case 1 -> {
                this.activity = 1.38;
                this.infoAboutActivity = "Тренировки средней тяжести 3 раза в неделю";
            }
            case 2 -> {
                this.activity = 1.46;
                this.infoAboutActivity = "Тренировки средней тяжести 5 раз в неделю";
            }
            case 3 -> {
                this.activity = 1.55;
                this.infoAboutActivity = "Интенсивные тренировки 5 раз в неделю";
            }
            case 4 -> {
                this.activity = 1.64;
                this.infoAboutActivity = "Тренировки каждый день";
            }
            case 5 -> {
                this.activity = 1.73;
                this.infoAboutActivity = "Интенсивные тренировки каждый день или по 2 раза в день";
            }
            case 6 -> {
                this.activity = 1.9;
                this.infoAboutActivity = "Ежедневная физическая нагрузка + физическая работа";
            }
                default -> throw new Exception();              
            }
        } catch (Exception e) {
            ps.println("Внимание!\nУ пользователя \"" + this.name + 
                    "\" введён некорректный коэффициент активности." + 
                    "\nАвтоматическая активность равна минимальной.\n ");
            this.activity = 1.2;
            this.infoAboutActivity = "Физическая нагрузка отсутствует или минимальная";
        }
    }
    //f.функцию расчета DCI
    public void countDCI() {
        int diff = sex ? 161 : 5;
        this.DCI = (weight*10 + height*6.25-age*5 - diff) * activity;
    }
    
    public void setCalories(double resCalories){
        this.totalCalories = resCalories;
    }
    public void countDifference(){        
        if (this.totalCalories - this.DCI > 0) {
            Person.ps.println(String.format("%s:\nНорма превышена."
            + "\nПревышение: %.2f ккал.\n", this.name, 
            this.totalCalories - this.DCI));
        } else {
            Person.ps.println(String.format("%s:\nНорма не превышена."
            + "\nОстаток: %.2f ккал.",this.name,
            this.DCI - this.totalCalories));
        }   
    }
    
    public void startNewDay() {
        this.totalCalories = 0;
    }
    public void printInfo(){
        ps.println(String.format("Имя: %s", name));
        ps.println(String.format("Рост: %.2f", height));
        ps.println(String.format("Вес: %.2f", weight));
        ps.println(String.format("Возраст: %d", age));
        ps.println(String.format("Пол: %s", sex?"женский":"мужской"));
        ps.println(String.format("Активность: %.2f (%s)", 
                activity, infoAboutActivity));     
        ps.println(String.format("DCI: %.3f.\n", DCI));
    }
}
