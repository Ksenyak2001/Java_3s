/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kondrashkinalab5.informationtolab5;
import java.util.ArrayList;
/**
 *
 * @author Kseny
 */
public class Lunch {
    int countMealLunch = 4, countMealDinner = 3, idFull = 0; 
    Food[] meals;
    int[] weightsMeal;
    public Lunch (int countMealLunch, int countMealDinner) {
        this.countMealLunch = countMealLunch;
        this.countMealDinner = countMealDinner;
        this.meals = new Food[this.countMealLunch+this.countMealDinner];
        this.weightsMeal = new int[this.countMealLunch+this.countMealDinner];
    }
    public void addMeal(int i, int weight, ArrayList<Food> all_food){
        meals[idFull] = all_food.get(i);
        weightsMeal[idFull++] = weight;        
    }
    public String getNameMeal(int i){
        return meals[i].getName();
    }
    public int getWeightMeal(int i){
        return weightsMeal[i];
    }
    public double getCaloryMeal(int i){
        return meals[i].CountCalories(weightsMeal[i]);
    }    
    public double countResCalories(){
        /* ��� ���������� ���������� �����:
        int border_up = 200, border_down = -100;
        int [] weightsMeal = new int[countMealLunch+countMealDinner];*/        
        double resCalories = 0;
        //System.out.println("������:");
        for (int k = 0; k < meals.length; ++k) {
            /*����� ��� ���������� ���������� �����:
            weightsMeal[k] = (int)(Math.random() * (border_up-border_down) + border_down);*/
            if (weightsMeal[k] > 0) {
                double tempCalory = meals[k].CountCalories(weightsMeal[k]);
                //System.out.println(String.format("%s: %d ����� (%.2f ����);", 
                //            meals[k].getName(), weightsMeal[k], tempCalory));
                resCalories += tempCalory;
            }            
        }
        //System.out.println(String.format("�����: %.2f ����.\n", resCalories));
        return resCalories;
    }
    public double changeWeight(String foodName, int gramm){
        for (int i = 0; i < this.meals.length; ++i){
            if (foodName.equals(meals[i].getName())){
                weightsMeal[i] = gramm;
            }
        }
        return countResCalories();
    }
    public double changeWeight(int gramm){
        for (int i = 0; i < this.countMealLunch+this.countMealDinner; ++i){
            this.weightsMeal[i] = gramm;
        }
        return countResCalories();
    }
    public double changeWeight(int foodName, int gramm){
        weightsMeal[foodName] = gramm;
        return countResCalories();
    }
    public double changeWeight(int foodName, double cal){
        double gramm = cal/meals[foodName].CountCalories();
        weightsMeal[foodName] = (int)gramm;
        return countResCalories();
    }
    public boolean checkId(String foodName){
        for (int i = 0; i < idFull;++i){
            if (meals[i].getName().equals(foodName)){
                return false;
            }
        }
        return true;
    }
}
