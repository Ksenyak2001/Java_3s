package kondrashkinalab5;
/**
 *
 * @author Ksenya Kondrashkina
 */
public class KondrashkinaLab5 {

    public static void main(String[] args) { 
        int countMealLunch = 4, countMealDinner = 3;              
        int countPerson = 4;
        
        UserWork todayUserWork = new UserWork(countPerson, countMealLunch, countMealDinner);
        todayUserWork.setPeopleLunch();
        todayUserWork.Hello();       
    }
}
