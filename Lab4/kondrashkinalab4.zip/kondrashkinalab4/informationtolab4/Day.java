/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kondrashkinalab4.informationtolab4;

/**
 *
 * @author Kseny
 */
public class Day {
    int day = 0, month = 0, id;
    float electricity = 0;
    public int[] dayInMonth= new int[]{31, 28, 31,30,31, 30, 31,31, 30 ,31,30,31};
    String[] month_name = new String[]{"January", "February", "March", "April", 
            "May", "June", "July", "August", "September", "October", "November", "December"};
    public Day(int d, float e) {        
        int i = 0, last_d = d;
        while(d > 0){
            last_d = d;
            d -= dayInMonth[i++];
        }
        this.month = i;
        this.day = last_d;
        this.id = d;
        this.electricity = e;
    }
    public int getId() {
        return id;
    }
    public int getDay(){
        return day;
    }
    public int getMonth(){
        return month;
    }
    public String getMonth(String name){
        return month_name[month-1];
    }
    public float getElectricity(){
        return electricity;
    }   
}
