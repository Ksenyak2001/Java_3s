/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kondrashkinalab4.informationtolab4;

/**
 *
 * @author Kseny
 */
public class Residents {
    Day [] electricityINDay;
    float priceElectricity;
    int[] dayInMonth;
    String[] namesMonth;
    public void printDay(int d){
        Day d_temp = new Day(d, 0);
        System.out.println(String.format("day %d in %d month", d_temp.getDay(), d_temp.getMonth()));
    }
    public Residents () {
        this.electricityINDay = new Day[365];
        this.priceElectricity = (float)2.5;
        this.dayInMonth= new int[]{0, 31, 28, 31,30,31, 30, 31,31, 30 ,31,30,31};
        this.namesMonth= new String[]{"January", "February", "March", "April", 
            "May", "June", "July", "August", "September", "October", "November", "December"};
        float border_up = 100, border_down = 0;        
        for (int i = 0; i < 365; ++i) {
            electricityINDay[i] =  new Day(i, 
                    (float)(Math.ceil(Math.random() * (border_up-border_down) 
                            + border_down)/2));
        }
    }
    public Day getDay(int day){
    return electricityINDay[day];
}
    public float getElectricity (int day, char c){
    return electricityINDay[day].getElectricity();
}
    public float getElectricity (int month){
    int prevdays = 0;
    for (int i = 0; i < month; ++i){
        prevdays += dayInMonth[i];
    }
    float res = 0;
    for (int j = prevdays; j < prevdays+dayInMonth[month]; ++j){
        res += electricityINDay[j].getElectricity();
    }
    return res;
}
    public float getElectricity (){
        float res = 0;
        for (int j = 0; j < 365; ++j){
            res += electricityINDay[j].getElectricity();
        }
        return res;
    }
    public float getPrice(int month){
        float electricity = this.getElectricity(month);
        return electricity*this.priceElectricity;
    }
    public float getPrice(){
        float electricity = this.getElectricity();
        return electricity*this.priceElectricity;
    }
    public int getRandomMaxMonth(){
        int nameMaxMonth = 0;
        float electricityMaxMonth = 0;
        for (int i = 1; i < 13; ++i){
            if (this.getElectricity(i) > electricityMaxMonth) {
                electricityMaxMonth = this.getElectricity(i);
                nameMaxMonth = i;
            }
        }
        return nameMaxMonth;
    }
    public String getRandomMaxMonth(String name ){
        int nameMaxMonth = 0;
        float electricityMaxMonth = -1;
        for (int i = 1; i < 13; ++i){
            if (this.getElectricity(i) > electricityMaxMonth) {
                electricityMaxMonth = this.getElectricity(i);
                nameMaxMonth = i;
            }
        }
        return this.namesMonth[nameMaxMonth-1];
    }
    public int[] getIdMaxMonth(){
        int[] nameMaxMonth = new int[12];
        float electricityMaxMonth = this.getElectricity(this.getRandomMaxMonth());
        for (int i = 1; i < 13; ++i){
            if (this.getElectricity(i) == electricityMaxMonth) {
                nameMaxMonth[i-1] = 1;
            }
        }
        return nameMaxMonth;
    }
    public int getRandomMinMonth(){
        int nameMinMonth = 0;
        float electricityMinMonth = -1;
        for (int i = 1; i < 13; ++i){
            if (this.getElectricity(i) < electricityMinMonth || electricityMinMonth==-1) {
                electricityMinMonth = this.getElectricity(i);
                nameMinMonth = i;
            }
        }
        return nameMinMonth;
    }
    public String getRandomMinMonth(String name ){
        int nameMinMonth = 0;
        float electricityMinMonth = -1;
        for (int i = 1; i < 13; ++i){
            if (this.getElectricity(i) < electricityMinMonth || electricityMinMonth==-1) {
                electricityMinMonth = this.getElectricity(i);
                nameMinMonth = i;
            }
        }
        return this.namesMonth[nameMinMonth-1];
    }
    public int[] getIdMinMonth(){
        int[] nameMaxMonth = new int[12];
        float electricityMinMonth = this.getElectricity(this.getRandomMinMonth());
        for (int i = 1; i < 13; ++i){
            if (this.getElectricity(i) == electricityMinMonth) {
                nameMaxMonth[i-1] = 1;
            }
        }
        return nameMaxMonth;
    }
    public float getAvg (int month){
        float electricity = this.getElectricity(month);
        return electricity / dayInMonth[month];
    }
    public int getMaxDay(){
        int day = 0;
        float electricity = -1;
        for (int i = 0; i < 365; ++i){            
            if (this.electricityINDay[i].getElectricity() > electricity){
                electricity=this.electricityINDay[i].getElectricity();
                day=i;
            }
        }      
        return day;
    }
    public int[] getAllMaxDay(){
        int day = this.getMaxDay();
        float electricity = this.getElectricity(day, 'd');
        int[] allMaxDays = new int[365];
        for (int i =0; i <365; ++i){
            if (electricity == this.getElectricity(i, 'd')){
                allMaxDays[i] = 1;
            } else {
                allMaxDays[i] = 0;
            }            
        }
        return allMaxDays;
    }
    public int getMinDay(){
        int day = 0;
        float electricity = -1;
        for (int i = 0; i < 365; ++i){
            if (this.electricityINDay[i].getElectricity() < electricity || electricity == -1){
                electricity=this.electricityINDay[i].getElectricity();
                day=i;
            }
        }      
        return day;
    }
    public int[] getIdMinDay(){
        int day = this.getMaxDay();
        float electricity = this.getElectricity(day, 'd');
        int[] allMinDays = new int[365];
        for (int i =0; i <365; ++i){
            if (electricity == this.getElectricity(i, 'd')){
                allMinDays[i] = 1;
            } else {
                allMinDays[i] = 0;
            }            
        }
        return allMinDays;
    }
}
    

