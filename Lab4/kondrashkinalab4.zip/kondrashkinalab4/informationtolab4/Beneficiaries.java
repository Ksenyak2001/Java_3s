/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kondrashkinalab4.informationtolab4;

/**
 *
 * @author Kseny
 */
public class Beneficiaries extends Residents {
    @Override
    public float getPrice(int month){
        float electricity = this.getElectricity(month);
        return electricity*this.priceElectricity*(float)0.75;
    }
    @Override
    public float getPrice(){
        float electricity = this.getElectricity();
        return electricity*this.priceElectricity*(float)0.75;
    }
}
