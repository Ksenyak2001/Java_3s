/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kondrashkinalab4.informationtolab4;

/**
 *
 * @author Kseny
 */
public class JKH {
    Residents[] people;
    int peopleWithoutBenefits = 0;
    String[] month = new String[]{"January", "February", "March", "April", 
            "May", "June", "July", "August", "September", "October", "November", "December"};
    public JKH(int p, int b) {
        this.people = new Residents[p+b];
        this.peopleWithoutBenefits = p;
    } 
    public Residents getResident(int id){
        return people[id];
    }
    public void fillJKH(){
        for (int i = 0; i < people.length; ++i){
            if (i < peopleWithoutBenefits) {
                people[i] = new Residents();
            } else {
                people[i] = new Beneficiaries();
            }
        }
    }
    public static String repeat(int count) {
        return new String(new char[count]).replace("\0", " ");
    }
    public void printTable(float[] firstArr, float[] secondArr){
        System.out.print(repeat(12) + "|");
        int size = 12;
        for (int k = 0; k < size; ++k){
            System.out.print(repeat(3)+(k+1)+repeat(4-(k+1)/10)+"|");
        }
        System.out.print("\nElectricity |");
        for (int k = 0; k < size; ++k){
            System.out.print(repeat(1)+String.format("%.1f",firstArr[k])+repeat(2)+"|");
        }
        System.out.print("\nPrice"+repeat(7)+"|");
        for (int k = 0; k < size; ++k){
            System.out.print(String.format("%.3f",secondArr[k])+"|");
        }
        System.out.print("\n");
    }
    public void printAvgPerson(int id){
        for (int i = 1; i < 13; ++i){
            System.out.println("Avg in "+ i + "("+people[id].namesMonth[i-1]+") = " + people[id].getAvg(i));
        }
    }    
    public void printAll() {
        
        for (int i = 0; i < people.length; ++i){
            System.out.println(String.format("\nPerson %d %s", i+1, i<this.peopleWithoutBenefits?"(without benefits)":"(with benefits)"));
            System.out.println(String.format("Electricity in year: %.3f", 
                    people[i].getElectricity()));
            System.out.println(String.format("Price for year: %.3f", 
                    people[i].getPrice()));
            
            float[] electricityEachMonth = new float[12];
            float[] priceEachMonth = new float[12];
            for (int j = 1; j < 13; ++j) {
                electricityEachMonth[j-1] = people[i].getElectricity(j);
                priceEachMonth[j-1] = people[i].getPrice(j);
            }
            printTable(electricityEachMonth,priceEachMonth);
            
        }
    }
    public int[] getMaxPeople(){
        float electricity = -1;
        float[] maxMonthElectr = new float[people.length];
        //находим макс электричество
        for (int i = 0; i < people.length; ++i){
            maxMonthElectr[i] = people[i].getElectricity(people[i].getRandomMaxMonth());            
            float electricity_temp  = maxMonthElectr[i];
            if (electricity_temp > electricity){
                electricity = electricity_temp;
            }
        }
        //находим людей с этим количеством
        int[] idAll = new int[people.length];
        for (int i = 0; i < people.length; ++i){
            float electricity_temp = maxMonthElectr[i];
            if (electricity_temp == electricity){
                idAll[i] = 1;
            } else {
                idAll[i] = 0;
            }
        }
        return idAll;
    }
    public void findMaxMonthPerson(){
        int[] idAll= getMaxPeople();
        //Для каждого человека с индексом 1 выводим максимум
        for (int i = 0 ; i < idAll.length; ++i){
            if (idAll[i] == 1) {
                int [] res = people[i].getIdMaxMonth();
                for (int j = 0; j < 12; ++j){
                    if (res[j] != 0) {
                        System.out.println(String.format("Person %d with"
                                + " min electricity = %.3f (per month - %d)",
                                i+1, people[i].getElectricity(j+1), j+1));
                    }
                }
            }    
        }
    }    
    public int[] getMinPeople(){
        float electricity = -1;
        float[] minMonthElectr = new float[people.length];
        //находим мин электричество
        for (int i = 0; i < people.length; ++i){
            minMonthElectr[i] = people[i].getElectricity(people[i].getRandomMinMonth());
            float electricity_temp = minMonthElectr[i];
            if (electricity_temp < electricity || electricity == -1){
                electricity = electricity_temp;
            }
        }
        //находим людей с этим количеством
        int[] idAll = new int[people.length];
        for (int i = 0; i < people.length; ++i){
            float electricity_temp = minMonthElectr[i];
            if (electricity_temp == electricity){
                idAll[i] = 1;
            } else {
                idAll[i] = 0;
            }
        }
        return idAll;
    }
    public void findMinMonthPerson(){
        int[] idAll=getMinPeople();
        //Для каждого человека с индексом 1 выводим максимум
        for (int i = 0 ; i < idAll.length; ++i){
            if (idAll[i] == 1) {
                int [] res = people[i].getIdMinMonth();
                for (int j = 0; j < 12; ++j){
                    if (res[j] != 0) {
                        System.out.println(String.format("Person %d with"
                                + " min electricity = %.3f (per month - %d)",
                                i+1, people[i].getElectricity(j+1), j+1));
                    }
                }
            }    
        }
    }
    public void findMaxMonthPerson(String name){
        int[] idAll= getMaxPeople();
        //Для каждого человека с индексом 1 выводим максимум
        for (int i = 0 ; i < idAll.length; ++i){
            if (idAll[i] == 1) {
                int [] res = people[i].getIdMaxMonth();
                for (int j = 0; j < 12; ++j){
                    if (res[j] != 0) {
                        System.out.println(String.format("Person %d with"
                                + " max electricity = %.3f (per month - %s)",
                                i+1, people[i].getElectricity(j+1), month[j]));
                    }
                }
            }    
        }
    }
    public void findMinMonthPerson(String name){
        int[] idAll=getMinPeople();
        //Для каждого человека с индексом 1 выводим максимум
        String[] month = new String[]{"January", "February", "March", "April", 
            "May", "June", "July", "August", "September", "October", "November", "December"};
        for (int i = 0 ; i < idAll.length; ++i){
            if (idAll[i] == 1) {
                int [] res = people[i].getIdMinMonth();
                for (int j = 0; j < 12; ++j){
                    if (res[j] != 0) {
                        System.out.println(String.format("Person %d with"
                                + " min electricity = %.3f (per month - %s)",
                                i+1, people[i].getElectricity(j+1), month[j]));
                    }
                }
            }    
        }
    }
    public void findMaxDayPerson(){
        float electricity = 0;
        float[] maxDayElectr = new float[people.length];
        //нашли самую большую электроэнергию в день
        for (int i = 0; i < people.length; ++i){
            maxDayElectr[i] = people[i].getElectricity(people[i].getMaxDay(), 'd');
            float electricity_temp = maxDayElectr[i];
            if (electricity_temp > electricity){
                electricity = electricity_temp;
            }
        }
        //находим людей с этим количеством
        int[] idAll = new int[people.length];
        for (int i = 0; i < people.length; ++i){
            float electricity_temp = maxDayElectr[i];
            if (electricity_temp == electricity){
                idAll[i] = 1;
            } else {
                idAll[i] = 0;
            }
        }
        //Для каждого человека с индексом 1 выводим максимум
        for (int i = 0 ; i < idAll.length; ++i){
            if (idAll[i] == 1) {
                for (int j = 0; j < 365; ++j) {
                    if (electricity == people[i].getElectricity(j, 'd')) {
                        System.out.println(String.format("Person %d with"
                                + " max electricity = %.1f (per day - %d, month - %d)",
                                i+1, electricity, people[i].getDay(j).getDay(),
                                people[i].getDay(j).getMonth()));
                        System.out.println(String.format("Person %d with"
                                + " max electricity = %.1f (per day - %d, month - %s)",
                                i+1, electricity, people[i].getDay(j).getDay(),
                                people[i].getDay(j).getMonth("name")));
                    }                    
                }
            }    
        }
    }
    public void findMinDayPerson(){
        float electricity = -1;
        float[] minDayElectr = new float[people.length];
        //нашли самую большую электроэнергию в день
        for (int i = 0; i < people.length; ++i){
            minDayElectr[i] = people[i].getElectricity(people[i].getMinDay(), 'd');
            float electricity_temp = minDayElectr[i];
            if (electricity_temp < electricity || electricity == -1){
                electricity = electricity_temp;
            }
        }
        
        //находим людей с этим количеством
        int[] idAll = new int[people.length];
        for (int i = 0; i < people.length; ++i){
            float electricity_temp = minDayElectr[i];
            if (electricity_temp == electricity){
                idAll[i] = 1;
            } else {
                idAll[i] = 0;
            }
        }
        //Для каждого человека с индексом 1 выводим максимум
        for (int i = 0 ; i < idAll.length; ++i){
            if (idAll[i] == 1) {
                for (int j = 0; j < 365; ++j) {
                    if (electricity == people[i].getElectricity(j, 'd')) {
                        System.out.println(String.format("Person %d with"
                                + " min electricity = %.1f (per day - %d, month - %d)",
                                i+1, electricity, people[i].getDay(j).getDay(),
                                people[i].getDay(j).getMonth()));
                    }                    
                }
            }    
        }
    }
}
