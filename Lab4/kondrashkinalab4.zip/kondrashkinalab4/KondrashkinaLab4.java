/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kondrashkinalab4;
import kondrashkinalab4.informationtolab4.*;
/**
 *
 * @author Kseny
 */
public class KondrashkinaLab4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        JKH database = new JKH(5,3);
        database.fillJKH();
        database.printAll();
        System.out.println("\nStatistic per month:");
        database.findMaxMonthPerson("name");   
        database.findMaxMonthPerson();   
        database.findMinMonthPerson();        
        System.out.println("\nStatistic per day:\nMax:");        
        database.findMaxDayPerson();
        System.out.println("Min:");
        database.findMinDayPerson();
        //Вывод среднего по месяцам
        int id = 2;
        System.out.println(String.format("\nAvg each month for %d person", id));
        database.printAvgPerson(id);
        //Вывод максимального месяца именем
        id = 3;
        System.out.println(String.format("\nMax month (%.3f kwatt) for %d person: %s", 
                database.getResident(id).getElectricity(database.getResident(id).getRandomMaxMonth()),
                id, database.getResident(id).getRandomMaxMonth("name")));
        
    }
    
}
